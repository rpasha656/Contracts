(function (global) {
  var config = {
    "meta": {
      "npm:@angular/*": {
        format: "cjs"
      },
      '*.css': { loader: 'text' },
      "*.html": { loader: 'text' }
    },
    paths: {
      // paths serve as alias
      'npm:': 'vendor/',
      'mui:': '//localhost:4205/'
    },
    // map tells the System loader where to look for things
    map: {
      "main": "main.js",
      "polyfills": "polyfills.js",
      // angular bundles
      '@angular/core': 'npm:@angular/core/bundles/core.umd.js',
      '@angular/common': 'npm:@angular/common/bundles/common.umd.js',
      '@angular/compiler': 'npm:@angular/compiler/bundles/compiler.umd.js',
      '@angular/platform-browser': 'npm:@angular/platform-browser/bundles/platform-browser.umd.js',
      '@angular/platform-browser-dynamic': 'npm:@angular/platform-browser-dynamic/bundles/platform-browser-dynamic.umd.js',
      '@angular/http': 'npm:@angular/http/bundles/http.umd.js',
      '@angular/router': 'npm:@angular/router/bundles/router.umd.js',
      '@angular/forms': 'npm:@angular/forms/bundles/forms.umd.js',
      'microui-contracts': 'npm:microui-contracts/dist',
      // other libraries
      'rxjs': 'npm:rxjs',
      'css': 'npm:systemjs-plugin-css/css.js',
      'core-js': 'npm:core-js',
      'text': 'npm:systemjs-plugin-text/text.js',
      'todolist': 'mui:',
      'lodash': 'npm:lodash'
    },
    // packages tells the System loader how to load when no filename and/or no extension
    packages: {
      app: {
        main: "index.js",
        defaultExtension: 'js',
        meta: {
          "*.html": {
            loader: 'text'
          }
        }
      },
      rxjs: 'cjs',
      'core-js': 'cjs',
      'lodash': '',
      'app/shared': 'cjs',
      environments: '',
      'microui-contracts': 'cjs',
      'mui:': {
        main: "main.js",
        defaultExtension: 'js',
        meta: {
          "*": {
            "decanonicalize": false
          }
        }
      }
    }
  };
  for (var key in config.packages) {
    var val = config.packages[key];
    if (typeof (val) === 'string') {
      config.packages[key] = {
        main: "index.js",
        defaultExtension: 'js'
      }
      if (val) {
        config.packages[key].format = val;
      }
    }
  }
  System.config(config);
})(this);
