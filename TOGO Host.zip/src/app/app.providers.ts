// import the contracts you want to inject
import { Title, PubSubServiceContract } from 'microui-contracts';
import { PubSubService } from 'microui-contracts/mocks';
export const APP_PROVIDERS = [
    // map the providers
    {
        provide: Title,
        useValue: 'This title was injected from the host!'
    },
    {
        provide: PubSubServiceContract,
        // You want to map to an "Instance" value rather than a class, 
        // since the state needs to be shared between host and the micro ui  
        useValue: new PubSubService()
    }
];
